v0.9b changes

- single phase input filter, R26 at 0R and diodes moved.
- opamp with footprints to try out-of-loop compensation (single resistor, or snubber) and in-the-loop compensation, also with sot-23 transistor footprint.
- jumpers included for switching in or out the burdens ( voltage output CT compatibility ).
- ac-ac input has footprint for 1210 burden smt. might give an option at loading the ac-ac adaptor to get a slightly more accurate representation of the mains signal.